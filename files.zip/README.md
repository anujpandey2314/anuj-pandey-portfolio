# Anuj Pandey — Developer Portfolio

A modern, premium, responsive personal portfolio website built with pure HTML, CSS, and JavaScript — no frameworks, no dependencies (except Google Fonts & Phosphor Icons via CDN).

---

## ✨ Features

- **Dark glassmorphism design** with blue + purple + cyan neon gradients
- **Animated particle canvas** with connected network effect in the hero
- **Typing effect** cycling through roles
- **Scroll reveal animations** — elements fade in as you scroll
- **Animated progress bars** for skill levels
- **Animated counters** for stats
- **Sticky navbar** with scroll-active section highlighting
- **Scroll progress bar** at the top of the page
- **Cursor glow** following the mouse
- **Loading screen** with animated progress fill
- **Back-to-top button** (appears after scrolling down)
- **Floating social icons** on the left side
- **Contact form** with local validation and success feedback
- **Fully responsive** — Desktop, Tablet, Mobile
- **Accessible** — keyboard navigable, reduced-motion respected, ARIA labels
- **SEO-friendly** meta tags

---

## 🗂️ Folder Structure

```
portfolio/
├── index.html              # Main HTML file
├── style.css               # All styles (organised by section)
├── script.js               # All JavaScript (modular IIFEs)
├── README.md               # This file
│
├── assets/
│   ├── profile.jpg         # Your profile photo (add yours here)
│   ├── hero-bg.jpg         # Optional hero background image
│   ├── criminal-management.png   # Project screenshot
│   ├── infosys-python.png        # Python cert image
│   └── infosys-ai.png            # AI cert image
│
└── resume/
    └── resume.pdf          # Your resume (add yours here)
```

---

## 🚀 How to Run

### Option 1 — Open directly
```bash
# Just open index.html in any modern browser
open index.html
```

### Option 2 — Local development server
```bash
# Using Python (built-in)
python3 -m http.server 8000
# Then visit: http://localhost:8000

# Using Node.js (npx)
npx serve .
```

---

## 🎨 Customisation Guide

### Personal details
- Open `index.html` and search for `anujpandey@email.com` — replace with your real email.
- Replace phone, LinkedIn URL, GitHub URL with yours.
- Add your profile photo at `assets/profile.jpg` (recommended: 400×400px).
- Add your resume PDF at `resume/resume.pdf`.

### Colors
All colours live in `:root` in `style.css`:
```css
--blue:    #4f8ef7;
--purple:  #a855f7;
--cyan:    #22d3ee;
```
Change these to retheme the entire site instantly.

### Adding a project
Copy an existing `<article class="project-card">` block in `index.html` and update the title, description, image path, tech tags, and links.

### Skill percentages
Change the `data-width` attribute on `.skill-fill` elements (0–100).

### Stat counters
Change the `data-target` attribute on `.stat-num` elements.

### Contact form
The form currently simulates a send. To wire it to a real backend, replace the `setTimeout` in `script.js` section 10 with a `fetch()` call to your API or a service like Formspree:
```javascript
fetch('https://formspree.io/f/YOUR_ID', {
  method: 'POST',
  body: new FormData(form),
  headers: { Accept: 'application/json' }
})
```

---

## 🛠️ Technologies Used

| Technology | Purpose |
|---|---|
| HTML5 | Structure & semantic markup |
| CSS3 | Styling, glassmorphism, animations |
| Vanilla JavaScript | Interactivity, canvas particles |
| CSS Custom Properties | Design token theming |
| IntersectionObserver API | Scroll-triggered animations |
| Canvas API | Particle network animation |
| Google Fonts | Space Grotesk + JetBrains Mono |
| Phosphor Icons (CDN) | Icon set |

---

## 📄 License

MIT License — free to use and modify for personal and commercial projects.

---

Made with ❤️ by **Anuj Pandey**
